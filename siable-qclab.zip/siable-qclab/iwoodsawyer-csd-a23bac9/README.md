[![View Cosine Sine Decomposition on File Exchange](https://www.mathworks.com/matlabcentral/images/matlab-file-exchange.svg)](https://www.mathworks.com/matlabcentral/fileexchange/50402-cosine-sine-decomposition)

CSD matlab function computes a cosine sine decompisition of an m-by-m partitioned orthogonal/unitary matrix X. The mex calls the SORCSD/DORCSD/CUNCSD/ZUNCSD named LAPACK functions.
